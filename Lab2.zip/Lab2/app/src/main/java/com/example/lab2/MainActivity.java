package com.example.lab2;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView cityList;
    ArrayAdapter<String> cityAdapter;
    ArrayList<String> dataList;
    Button addCityButton, deleteCityButton, confirmButton;
    EditText inputCity;
    int selectedPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the UI elements
        cityList = findViewById(R.id.city_list);
        addCityButton = findViewById(R.id.add_city_button);
        deleteCityButton = findViewById(R.id.delete_city_button);
        inputCity = findViewById(R.id.input_city);
        confirmButton = findViewById(R.id.confirm_button);

        // Set the confirm button and input field to be hidden initially
        inputCity.setVisibility(View.GONE);
        confirmButton.setVisibility(View.GONE);

        // Initialize the city list and adapter
        dataList = new ArrayList<>();
        dataList.add("Edmonton");
        dataList.add("Vancouver");
        dataList.add("Moscow");

        cityAdapter = new ArrayAdapter<>(this, R.layout.context, R.id.content_view, dataList);
        cityList.setAdapter(cityAdapter);

        // Handle Add City button click
        addCityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputCity.setVisibility(View.VISIBLE);
                confirmButton.setVisibility(View.VISIBLE);
            }
        });

        // Handle Confirm button click to add city
        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newCity = inputCity.getText().toString().trim();
                if (!newCity.isEmpty()) {
                    dataList.add(newCity);
                    cityAdapter.notifyDataSetChanged();
                    inputCity.setText("");
                    inputCity.setVisibility(View.GONE);
                    confirmButton.setVisibility(View.GONE);
                }
            }
        });

        // Handle ListView item click to select a city
        cityList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedPosition = position;
                String selectedCity = dataList.get(position);
            }
        });

        // Handle Delete City button click
        deleteCityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPosition >= 0) {
                    String removedCity = dataList.remove(selectedPosition);
                    cityAdapter.notifyDataSetChanged();
                    selectedPosition = -1;

                }
            }
        });
    }
}
